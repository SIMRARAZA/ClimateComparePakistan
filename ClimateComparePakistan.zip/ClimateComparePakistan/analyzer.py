
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


class WeatherAnalyzer:

    def __init__(self, current_data, forecast_data):
        self.df = pd.DataFrame(current_data)

    def show_analysis(self):
        print("\n===== PAKISTAN WEATHER COMPARISON =====")
        print(self.df.to_string(index=False))

        print("\n===== TEMPERATURE STATISTICS =====")
        print("Total Cities:", len(self.df))

        average = np.mean(self.df["Temperature"])
        print("Average Temperature:", round(average, 2), "°C")

        warmest = self.df.loc[
            self.df["Temperature"].idxmax(), "City"
        ]

        coolest = self.df.loc[
            self.df["Temperature"].idxmin(), "City"
        ]

        print("Warmest City:", warmest)
        print("Coolest City:", coolest)

    def save_csv(self):
        os.makedirs("output", exist_ok=True)

        self.df.to_csv(
            "output/weather_data.csv", index=False
        )

        print("\nWeather CSV saved successfully!")

    def create_graphs(self):
        os.makedirs("output", exist_ok=True)

        plt.figure(figsize=(11, 6))

        plt.bar(
            self.df["City"],
            self.df["Temperature"]
        )

        plt.title("Temperature Comparison of Pakistani Cities")
        plt.xlabel("Cities of Pakistan")
        plt.ylabel("Temperature (°C)")
        plt.xticks(rotation=35)
        plt.tight_layout()

        plt.savefig(
            "output/temperature_comparison.png",
            dpi=150
        )

        plt.show()
        plt.close()

        print("\nTemperature graph saved successfully!")
