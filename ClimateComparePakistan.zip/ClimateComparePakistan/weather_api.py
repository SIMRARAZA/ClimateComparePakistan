
import os
import requests
from dotenv import load_dotenv
from pydantic import BaseModel, Field

load_dotenv()

API_URL = os.getenv("API_URL")


# Pydantic model
class WeatherData(BaseModel):
    City: str
    Temperature: float
    Humidity: float = Field(ge=0, le=100)
    Wind_Speed: float = Field(ge=0)
    Precipitation: float = Field(ge=0)


# Parent class
class DataAPI:
    def fetch_city_data(self, latitude, longitude):
        if not API_URL:
            raise ValueError("API_URL is missing from .env")

        params = {
            "latitude": latitude,
            "longitude": longitude,
            "current": (
                "temperature_2m,relative_humidity_2m,"
                "wind_speed_10m,precipitation"
            ),
            "daily": (
                "temperature_2m_max,temperature_2m_min,"
                "precipitation_sum"
            ),
            "timezone": "auto",
            "forecast_days": 7
        }

        response = requests.get(
            API_URL, params=params, timeout=20
        )
        response.raise_for_status()
        return response.json()


# Child class: inheritance
class WeatherAPI(DataAPI):
    def __init__(self):
        self.cities = {
    "Lahore": (31.5204, 74.3587),
    "Multan": (30.1575, 71.5249),
    "Dera Ghazi Khan": (30.0561, 70.6348),
    "Faisalabad": (31.4504, 73.1350),
    "Karachi": (24.8607, 67.0011),
    "Quetta": (30.1798, 66.9750),
    "Islamabad": (33.6844, 73.0479),
    "Peshawar": (34.0151, 71.5249)
}


    def get_weather(self):
        current_data = []
        forecast_data = []

        for city, (latitude, longitude) in self.cities.items():
            data = self.fetch_city_data(latitude, longitude)
            current = data["current"]

            weather = WeatherData(
                City=city,
                Temperature=current["temperature_2m"],
                Humidity=current["relative_humidity_2m"],
                Wind_Speed=current["wind_speed_10m"],
                Precipitation=current["precipitation"]
            )

            current_data.append({
                "City": weather.City,
                "Temperature": weather.Temperature,
                "Humidity": weather.Humidity,
                "Wind Speed": weather.Wind_Speed,
                "Precipitation": weather.Precipitation
            })

            daily = data["daily"]

            for i, date in enumerate(daily["time"]):
                forecast_data.append({
                    "City": city,
                    "Date": date,
                    "Max Temperature": daily["temperature_2m_max"][i],
                    "Min Temperature": daily["temperature_2m_min"][i],
                    "Precipitation": daily["precipitation_sum"][i]
                })

        return current_data, forecast_data


if __name__ == "__main__":
    api = WeatherAPI()
    current_data, forecast_data = api.get_weather()

    for item in current_data:
        print(item)

    print("\nWeather data fetched successfully!")
