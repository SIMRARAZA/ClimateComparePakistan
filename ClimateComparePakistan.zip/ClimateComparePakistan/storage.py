import os
import sqlite3
from datetime import datetime
import pandas as pd

DB_PATH = "output/weather_history.db"


class WeatherStorage:
    def __init__(self, db_path=DB_PATH):
        os.makedirs("output", exist_ok=True)
        self.db_path = db_path
        self._create_table()

    def _create_table(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS weather_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    fetched_at TEXT NOT NULL,
                    city TEXT NOT NULL,
                    temperature REAL,
                    humidity REAL,
                    wind_speed REAL,
                    precipitation REAL
                )
            """)

    def save(self, df):
        data = df.copy()
        data.columns = ["city", "temperature", "humidity",
                        "wind_speed", "precipitation"]
        data.insert(0, "fetched_at",
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

        with sqlite3.connect(self.db_path) as conn:
            data.to_sql("weather_history", conn,
                        if_exists="append", index=False)
        print("\nData saved to history database!")

    def load_history(self, city=None):
        query = "SELECT * FROM weather_history"
        params = ()
        if city:
            query += " WHERE city = ?"
            params = (city,)
        query += " ORDER BY fetched_at"

        with sqlite3.connect(self.db_path) as conn:
            return pd.read_sql_query(query, conn, params=params)