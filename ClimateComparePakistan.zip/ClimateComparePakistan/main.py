from weather_api import WeatherAPI
from analyzer import WeatherAnalyzer
from storage import WeatherStorage


def main():
    try:
        api = WeatherAPI()

        print("Fetching weather data for multiple cities...")
        current_data, forecast_data = api.get_weather()

        print("Weather data fetched successfully!")

        analyzer = WeatherAnalyzer(current_data, forecast_data)
        analyzer.show_analysis()
        analyzer.save_csv()
        analyzer.create_graphs()

        # History store karo
        storage = WeatherStorage()
        storage.save(analyzer.df)

        history = storage.load_history()
        history.to_csv("output/weather_history.csv", index=False)
        print("\n===== PREVIOUS DATA =====")
        print(history.tail(16).to_string(index=False))

    except Exception as error:
        print("Error:", error)


if __name__ == "__main__":
    main()